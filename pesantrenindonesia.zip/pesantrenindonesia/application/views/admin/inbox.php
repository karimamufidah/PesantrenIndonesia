        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

          <div class="row">
          	<div class="col-lg">
          <table class="table table-hover">
  					<thead>
    					<tr>
      						<th scope="col">#</th>
      						<th scope="col">Nama</th>
      						<th scope="col">Email</th>
                  			<th scope="col">Subject</th>
                  			<th scope="col">Action</th>
    					</tr>
  					</thead>
  					<tbody>
  						<?php $i =1; ?>
  						<?php foreach ($inbox as $in) : ?>
    					<tr>
      						<th scope="row"><?= $i; ?></th>
      						<td><?= $in['nama']; ?></td>
                  			<td><?= $in['email']; ?></td>
                  			<td><?= $in['subject']; ?></td>
      						<td>
      							<a href="detailInbox/<?= $in['id']; ?>" class="badge badge-primary"> Detail </a>
      							<a href="deleteInbox/<?= $in['id']; ?>" class="badge badge-danger"> Delete </a>
      						</td>
    					</tr>
    				<?php $i++; ?>
    				<?php endforeach; ?>
  					</tbody>
				</table>
				</div>
				</div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->