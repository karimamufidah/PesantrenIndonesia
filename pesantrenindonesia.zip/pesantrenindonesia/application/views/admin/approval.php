

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

          <div class="row">
          	<div class="col-lg">
          <table class="table table-hover">
  					<thead>
    					<tr>
      						<th scope="col">#</th>
      						<th scope="col">Nama Pesantren</th>
                  			<th scope="col">Status</th>
                  			<th scope="col">Action</th>
    					</tr>
  					</thead>
  					<tbody>
  						<?php $i =1; ?>
  						<?php if(is_array($pesantren)){
                foreach ($pesantren as $pes){
            ?>
    					<tr>
      						<th scope="row"><?= $i; ?></th>
      						<td><?= $pes['nama_pesantren']; ?></td>
                  <td><?= $pes['status']; ?></td>	
                  <td>
                  	<a href="detail/<?= $pes['id_pesantren']; ?>" class="badge badge-primary"> Detail </a>
                    <a href="approve/<?= $pes['id_pesantren']; ?>" class="badge badge-success" onclick="return confirm('You are going to approve this data. Are you sure?');"> Approve </a>
                    <a href="delete/<?= $pes['id_pesantren']; ?>" class="badge badge-danger" onclick="return confirm('You are going to approve this data. Are you sure?');"> Delete </a>
      						</td>
    					</tr>
    				<?php $i++; ?>
            <?php 
              }
            } ?>
  					</tbody>
				</table>
				</div>
				</div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      