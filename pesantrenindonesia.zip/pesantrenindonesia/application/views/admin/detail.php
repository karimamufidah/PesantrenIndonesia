<!-- banner -->
<section class="inner-banner">
	<div class="container">
	</div>
</section>
<!-- //banner -->

<div class="container">
    <?php if(is_array($inbox)){
        foreach ($inbox as $in){
            ?>
<div class="card" style="margin: auto; width: 40rem;" >
        
            <div class="card-body">
                <h3 class="card-title">Detail Pesan</h3>
                    <h5>Nama:</h5>
                    <p class="card-text"><?= $in['nama'] ?></p>
                    <h5>Email:</h5>
                    <p class="card-text"><?= $in['email'] ?></p>
                    <h5>No Telepon:</h5>
                    <p class="card-text"><?= $in['notelp'] ?></p>
                    <h5>Subject:</h5>
                    <p class="card-text"><?= $in['subject'] ?></p>
                    <h5>Pesan:</h5>
                    <p class="card-text"><?= $in['pesan'] ?></p>
                    
                    <a href="<?= base_url('admin/inbox');  ?>" class="btn btn-primary">Kembali</a>
                
            </div>
    </div>
    <?php 
        }
    } ?>
</div>