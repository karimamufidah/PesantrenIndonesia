<!-- banner -->
<section class="inner-banner">
	<div class="container">
	</div>
</section>
<!-- //banner -->

<div class="container">
	<?php foreach ($pesantren as $pes) : ?>
	<div class="card" style="margin: auto; width: 40rem;" >
  		<img src="<?= base_url('assets/images/pesantren/') . $pes['foto_pesantren']; ?>" class="card-img-top" alt="...">
  			<div class="card-body">
    			<h3 class="card-title"><?= $pes['nama_pesantren'] ?></h3>
    				<h5>Nama Pengurus:</h5>
    				<p class="card-text"><?= $pes['nama_pengurus'] ?></p>
    				<h5>Jabatan Pengurus:</h5>
    				<p class="card-text"><?= $pes['jabatan_pengurus'] ?></p>
    				<h5>Email:</h5>
    				<p class="card-text"><?= $pes['email_pesantren'] ?></p>
    				<h5>Website:</h5>
    				<p class="card-text"><?= $pes['website_pesantren'] ?></p>
    				<h5>No Telepon:</h5>
    				<p class="card-text"><?= $pes['notelp_pesantren'] ?></p>
    				<h5>Alamat:</h5>
    				<p class="card-text"><?= $pes['alamat_pesantren'] ?></p>
    				<p class="card-text"><?= $pes['kab_kota_pesantren'] ?>, <?= $pes['provinsi_pesantren'] ?></p>
    				<p class="card-text"><?= $pes['kodepos_pesantren'] ?></p>
    				<a href="<?= base_url('home/search');  ?>" class="btn btn-primary">Kembali</a>
  				<?php endforeach; ?>
  			</div>
	</div>	
</div>