
<!-- banner -->
<section class="banner">
	<div class="container">
		<div class="row banner-grids">
			<div class="col-lg-6 banner-info">
				<h2 class="">Informasi Pesantren di</h2>
				<h3 class="mb-3">Indonesia</h3>
				<p class="mb-4"> Temukan informasi mengenai pesantren di seluruh Indonesia dari sumber terpercaya. Anda juga bisa mendaftarkan atau menambahkan informasi mengenai pesantren dengan mudah agar menjadi kebermanfaatan bagi semuanya.</p>
				<a href="daftar">DAFTAR SEKARANG</a>
			</div>
			<div class="col-lg-6 col-md-9 banner-image">
				<img src="assets/images/lugu.JPG" alt="" class="img-fluid"/>
			</div>
		</div>
	</div>
</section>
<!-- //banner -->

<!-- about -->
<section class="about py-5">
	<div class="container">
		<div class="inner-sec-w3ls py-lg-5 py-3">
			<div class="heading">
				<h3 class="head text-center">Cari Pesantren </h3>
				<p class="my-3 head text-center"> Anda dapat mencari pesantren untuk mendapatkan informasi lebih lanjut mengenai pesantren dengan mengetikkan nama pesantren pada kolom pencarian di bawah ini.</p>
			</div>
		          <form class="example" action="home/search">
                    <input type="text" placeholder="Ketik nama pesantren disini..." name="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
		</div>
	</div>
</section>
<!-- //about -->

<!-- latest news -->
<!-- <section class="latest-news py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center">Pencarian Populer </h3>
			<p class="my-3 head text-center"> Berikut ini adalah pencarian populer pesantren yang ada di Indonesia. <br>
                Untuk melihat informasi pesantren lainnya, Anda dapat melihat laman Cari Pesantren.</p>
		</div>
		<div class="row news_grids mx-auto mt-5 pt-3">
			<div class="row col-lg-10 p-lg-auto p-0 mx-auto">
				<div class="col-md-6">
					<div class="blog-post mb-4">
						<div class="bg-light p-4">
							<h5 class="card-title">Management Values</h5>
							<h4 class="">The working process of our team work</h4>
						</div>
						<img src="assets/images/bp1.jpg" alt="" class="img-fluid"/>
					</div>
					<a href="#"> Selengkapnya </a>
				</div>
				<div class="col-md-6 mt-md-0 mt-5">
					<div class="blog-post mb-4">
						<div class="bg-light p-4">
							<h5 class="card-title">Management Values</h5>
							<h4 class="">The working process of our team work</h4>
						</div>
						<img src="assets/images/bp2.png" alt="" class="img-fluid"/>
					</div>
					<a href="#"> Selengkapnya </a>
				</div>
				<div class="col-12 text-center">
					<a href="pencarian" class="more_blog_link">Lihat Pesantren Lainnya</a>
				</div>
			</div>
		</div>
	</div>
</section> -->
<!-- //latest news -->

<!-- improvements -->
<section class="stats bg-light py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center" style="font-size: 15px">Visi &amp; Misi</h3>
			<p class="my-3 head text-center"> Pesantren Indonesia merupakan website kumpulan informasi mengenai pesantren-pesantren di seluruh wilayah Indonesia dengan tujuan dapat menjalin silaturahmi antar pesantren dan juga pihak luar.</p>
		</div>
		<div class="row text-center mt-5"> 
			<div class="col-md-4">
				<div class="bg-white p-4">
					<!--h4>1</h4-->
					<p class="my-3"> Meningkatkan hubungan antar pesantren di seluruh wilayah Indonesia </p>
				</div>
			</div>
			<div class="col-md-4 mt-md-0 mt-3">
				<div class="bg-white p-4">
					<!--h4>2</h4-->
					<p class="my-3"> Mengetahui dan meningkatkan kerja, kinerja, SDA, dan SDM yang ada di pesantren </p>
				</div>
			</div>
			<div class="col-md-4 mt-md-0 mt-3">
				<div class="bg-white p-4">
					<!--h4>3</h4-->
					<p class="my-3"> Menjalin kerjasama yang saling menguntungkan antar pesantren dan pihak luar </p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //improvements -->
