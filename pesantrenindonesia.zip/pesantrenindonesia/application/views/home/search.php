
<!-- banner -->
<section class="inner-banner">
	<div class="container">
	</div>
</section>
<!-- //banner -->


<!-- latest news -->
<section class="latest-news py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center">Cari Pesantren </h3>
			<p class="my-3 head text-center">  Anda dapat mencari pesantren untuk mendapatkan informasi lebih lanjut mengenai pesantren dengan mengetikkan nama pesantren pada kolom pencarian di bawah ini.</p>
            
            <form class="example" action="<?= base_url('home/searchbutton'); ?>" method="post">
                    <input type="text" placeholder="Ketik nama pesantren disini..." name="keyword" id="keyword" autocomplete="off">
                    <button type="submit"><i class="fa fa-search"></i></button>
            </form>
            
		</div>
		<div class="row news_grids mx-auto mt-5 pt-3">
			<?php foreach ($pesantren as $pes) : ?>
			<div class="col-lg-4 col-md-6 mt-5">
				<div class="blog-post mb-4">
					<div class="bg-light p-4">
						<h5 class="card-title"><?= $pes['kab_kota_pesantren'] ?>, <?= $pes['provinsi_pesantren'] ?></h5>
						<h4 class=""><?= $pes['nama_pesantren'] ?></h4>
					</div>
					<img src="<?= base_url('assets/images/pesantren/') . $pes['foto_pesantren']; ?>" alt="" class="img-fluid"/>
				</div>
				<a href="detail/<?= $pes['id_pesantren']; ?>"> Selengkapnya </a>
			</div>
			<?php endforeach; ?>			
		</div>
	</div>
</section>
<!-- //latest news -->

    
    <script>
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
        }

    function filterFunction() {
        var input, filter, ul, li, a, i;
        input = document.getElementById("myInput");
        filter = input.value.toUpperCase();
        div = document.getElementById("myDropdown");
        a = div.getElementsByTagName("a");
        for (i = 0; i < a.length; i++) {
            txtValue = a[i].textContent || a[i].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    a[i].style.display = "";
                    } else {
                    a[i].style.display = "none";
                    }
            }
    }
    </script>