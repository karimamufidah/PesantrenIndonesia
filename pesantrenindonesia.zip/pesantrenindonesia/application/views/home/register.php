<!-- banner -->
<section class="inner-banner">
	<div class="container">
	</div>
</section>
<!-- //banner -->


<!-- latest news -->
<section class="latest-news py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center">Daftarkan Pesantren </h3>
			<p class="my-3 head text-center"> Isikan formulir di bawah ini untuk mendaftarkan pesantren. </p>
			<div class="row justify-content-center">
				<div class="col-lg-9 my-3">
					<?= $this->session->flashdata('message'); ?>
					<form action="<?= base_url('home/register'); ?>" method="post">
          		<div class="form-group row">
    				<label for="namaPesantren" class="col-sm-3 col-form-label">Nama Pesantren</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="namaPesantren" name="namaPesantren" placeholder="Nama pesantren">
    					<?= form_error('namaPesantren', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<label for="namaPengurus" class="col-sm-3 col-form-label">Nama Pengurus</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="namaPengurus" name="namaPengurus" placeholder="Nama pengurus">
    					<?= form_error('namaPengurus', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<label for="jabatanPengurus" class="col-sm-3 col-form-label">Jabatan Pengurus</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="jabatanPengurus" name="jabatanPengurus" placeholder="Jabatan pengurus">
    					<?= form_error('jabatanPengurus', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<label for="emailPesantren" class="col-sm-3 col-form-label">Email</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="emailPesantren" name="emailPesantren" placeholder="Email">
    					<?= form_error('emailPesantren', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<label for="websitePesantren" class="col-sm-3 col-form-label">Website</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="websitePesantren" name="websitePesantren" placeholder="Website">
    					<?= form_error('websitePesantren', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
				<div class="form-group row">
    				<label for="notelp" class="col-sm-3 col-form-label">No Telepon</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="notelp" name="notelp" placeholder="No Telepon">
    					<?= form_error('notelp', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<label for="alamat" class="col-sm-3 col-form-label">Alamat</label>
    				<div class="col-sm-9">
    					<input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat">
    					<?= form_error('alamat', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row justify-content-end">
    				<div class="col-sm-3">
    					<input type="text" class="form-control" id="provinsi" name="provinsi" placeholder="Provinsi">
    					<?= form_error('provinsi', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
    				<div class="col-sm-3">
    					<input type="text" class="form-control" id="kabkota" name="kabkota" placeholder="Kabupaten/Kota">
    					<?= form_error('kabkota', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
    				<div class="col-sm-3">
    					<input type="text" class="form-control" id="kodepos" name="kodepos" placeholder="Kode pos">
    					<?= form_error('kodepos', '<small class="text-danger pl-3">', '</small>') ?>
    				</div>
  				</div>
  				<div class="form-group row">
    				<div class="col-sm-3">Gambar</div>
    				<div class="col-sm-9">
    					<div class="row">
    						<div class="col-sm-9">
    							<div class="custom-file">
  									<input type="file" class="custom-file-input" id="gambar" name="gambar">
  									<label class="custom-file-label" for="gambar">Pilih file</label>
                    <?= form_error('gambar', '<small class="text-danger pl-3">', '</small>') ?>
								</div>
    						</div>
    					</div>
    				</div>
  				</div>
  				<div class="form-group row justify-content-end">
  					<div class="col-sm-9">
  						<button type="submit" class="btn btn-primary">Submit</button>
  					</div>
  				</div>
          	</form>
				</div>
			</div>
			
		</div>
	</div>
</section>
<!-- //latest news -->
