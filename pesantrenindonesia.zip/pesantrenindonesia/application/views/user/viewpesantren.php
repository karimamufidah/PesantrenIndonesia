<!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

          <div class="row">
          	<div class="col-lg">
          <table class="table table-hover">
  					<thead>
    					<tr>
      						<th scope="col">#</th>
      						<th scope="col">Nama Pesantren</th>
      						<th scope="col">Nama Pengurus</th>
                  			<th scope="col">Jabatan Pengurus</th>
                  			<th scope="col">Email</th>
                  			<th scope="col">Website</th>
                  			<th scope="col">No Telepon</th>
                  			<th scope="col">Alamat</th>
                  			<th scope="col">Provinsi</th>
                  			<th scope="col">Kab/Kota</th>
                  			<th scope="col">Kodepos</th>
    					</tr>
  					</thead>
  					<tbody>
  						<?php $i =1; ?>
  						<?php foreach ($pesantren as $pes) : ?>
    					<tr>
      						<th scope="row"><?= $i; ?></th>
      						<td><?= $pes['nama_pesantren']; ?></td>
                  			<td><?= $pes['nama_pengurus']; ?></td>
                  			<td><?= $pes['jabatan_pengurus']; ?></td>
                  			<td><?= $pes['email_pesantren']; ?></td>
                  			<td><?= $pes['website_pesantren']; ?></td>
                  			<td><?= $pes['notelp_pesantren']; ?></td>
                  			<td><?= $pes['alamat_pesantren']; ?></td>
                  			<td><?= $pes['provinsi_pesantren']; ?></td>
                  			<td><?= $pes['kab_kota_pesantren']; ?></td>
                  			<td><?= $pes['kodepos_pesantren']; ?></td>
    					</tr>
    				<?php $i++; ?>
    				<?php endforeach; ?>
  					</tbody>
				</table>
				</div>
				</div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->