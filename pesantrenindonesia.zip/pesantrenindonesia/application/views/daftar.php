<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Pesantren Indonesia</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Work Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
	<!-- css files -->
    <link href="assets/css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="assets/css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="assets/css/fontawesome-all.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Mukta:200,300,400,500,600,700,800&amp;subset=devanagari,latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Niramit:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
	
</head>
<body>

<!-- header -->
<header class="bg-white py-1">
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light">
			<h1>
				<a class="navbar-brand" href="home"><!--i class="fab fa-python"></i--> Pesantren Indonesia</a>
			</h1>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-lg-4 mr-auto">
				  <li class="nav-item active">
					<a class="nav-link" href="pencarian">Cari Pesantren <span class="sr-only">(current)</span></a>
				  </li>
				  <!--li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					  Why Us?
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					  <a class="dropdown-item" href="features">Features</a>
					  <a class="dropdown-item" href="blogs">Company Stories</a>
					  <a class="dropdown-item" href="pricing">Pricing</a>
					</div>
				  </li-->
				  <!--li class="nav-item dropdown">
					<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					  Dropdown
					</a>
					<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					  <a class="dropdown-item" href="faq">faq's</a>
					  <a class="dropdown-item" href="security">Security</a>
					  <a class="dropdown-item" href="typography">Typography</a>
					</div>
				  </li-->
				  <li class="nav-item">
					<a class="nav-link" href="contact">Daftarkan Pesantren</a>
				  </li>
                    <li class="nav-item">
					<a class="nav-link" href="contact">Kontak</a>
				  </li>
				</ul>
				<div class="header-right">
					<a href="masuk" class="signin mr-4"> Masuk <i class="fas fa-sign-in-alt"></i></a>
					<a href="daftar" class="contact">DAFTAR</a>
				</div>
			</div>
		</nav>
	</div>
</header>
<!-- //header -->

<!-- banner -->
<section class="inner-banner">
	<div class="container">
	</div>
</section>
<!-- //banner -->

<!-- signin -->
<section class="signin py-5">
	<div class="container">
		<div class="row main-content-agile">
			<div class="col-md-6">	
				<div class="sub-main-w3 text-center">	
					<h3>Buat akun</h3>
					<p class="mt-2 mb-4">Masukkan detail Anda untuk membuat akun.</p>
					
                    <form class="user">
						<div class="form-group">
							<input type="text" class="form-control form-control-user" id="name" name="name" placeholder="Nama Lengkap">
						</div>
						<div class="form-group">
							<input type="text" class="form-control form-control-user" id="email" name="email" placeholder="Email">
						</div>
						<div class="form-group">
							<input type="password" class="form-control form-control-user" id="password1" name="password1" placeholder="Password">
						</div>
                        <div class="form-group">
							<input type="password" class="form-control form-control-user" id="password2" name="password2" placeholder="Konfirmasi Password">
						</div>
                    <button class="btn btn-primary btn-user btn-block" type="submit"> Daftar </button>
						<p>Sudah memiliki Akun? <a href="masuk" class="ml-2"><strong>Masuk ke akun Anda</strong></a></p>
					</form>
				</div>
			</div>
			<div class="col-md-6">
				<img src="assets/images/lugu.JPG" alt="" class="img-fluid"/>
			</div>
		</div>
	</div>
</section>
<!-- //signin -->

<!-- footer -->
<!--footer class="footer py-5">
	<div class="container py-sm-4">
		<div class="row">
			<div class="col-lg-4 mb-lg-0 mb-4 footer-top">
				<h2>
				<a class="navbar-brand" href="home"><i class="fab fa-python"></i> Work</a>
				</h2>
				<p class="my-3 head"> Vestibulum ante ipsum primis in faucib orci luctus et ultrices posuere cubilia Curae, Nul mollis dapibus nunc, ut rhoncus
				turpis sod quis. Integer sit amet mattis quam.</p>
			</div>
			<div class="col-lg-2 col-sm-3 col-6 footv3-left">
				<h4 class="mb-4 w3f_title text-uppercase">Company</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="about">
							About Us
						</a>
					</li>
					<li class="mb-2">
						<a href="features">
							Features
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Projects
						</a>
					</li>
					<li class="my-2">
						<a href="blogs">
							Blog Posts
						</a>
					</li>
					<li>
						<a href="contact">
							Get In Touch
						</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-2 col-sm-3 col-6">
				<h4 class="mb-4 w3f_title text-uppercase">Product</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Why Us?
						</a>
					</li>
					<li class="mb-2">
						<a href="features">
							Features
						</a>
					</li>
					<li class="my-2">
						<a href="security">
							Security
						</a>
					</li>
					<li class="my-2">
						<a href="pricing">
							Pricing
						</a>
					</li>
					<li>
						<a href="#">
							Settings
						</a>
					</li>
				</ul>
			</div>

			<div class="col-lg-2 col-sm-3 col-6 mt-sm-0 mt-4">
				<h4 class="mb-4 w3f_title text-uppercase">Resources</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Help Line
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							Steps To Follow
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Guidance
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Download
						</a>
					</li>
					<li>
						<a href="#">
							Mobile App
						</a>
					</li>
				</ul>
			</div>
			
			<div class="col-lg-2 col-sm-3 col-6 mt-sm-0 mt-4">
				<h4 class="mb-4 w3f_title text-uppercase">Extras</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Extra Links
						</a>
					</li>
					<li class="mb-2">
						<a href="signin">
							Login
						</a>
					</li>
					<li class="my-2">
						<a href="register">
							Register
						</a>
					</li>
				</ul>
			</div>
			
		</div>
	</div>
	<!-- //footer bottom -->
<!--/footer-->
<!-- //footer -->

<!-- copyright -->
<section class="copy-right bg-light py-4">
	<div class="container">
		<div class="row">
			<div class="col-lg-7 col-md-9">
				<p class="">© 2019 Pesantren Indonesia. All rights reserved
				</p>
			</div>
			<div class="col-lg-5 col-md-3">
				<ul class="social-iconsv2 agileinfo d-flex">
					<li>
						<a href="#">
							<i class="fab fa-facebook-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-twitter-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-google-plus-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-linkedin"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- copyright -->

    <!-- js -->
    <script src="assets/js/jquery-2.2.3.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <!-- //js -->
	
	<!-- dropdown nav -->
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                    $(this).toggleClass('open');
                },
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                    $(this).toggleClass('open');
                }
            );
        });
    </script>
    <!-- //dropdown nav -->

	<script src="assets/js/smoothscroll.js"></script><!-- Smooth scrolling -->


</body>
</html>