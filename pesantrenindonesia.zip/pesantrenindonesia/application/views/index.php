<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Pesantren Indonesia</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Work Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
	
	<!-- css files -->
    <link href="assets/css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="assets/css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
    <link href="assets/css/fontawesome-all.css" rel="stylesheet"><!-- fontawesome css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Mukta:200,300,400,500,600,700,800&amp;subset=devanagari,latin-ext" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Niramit:200,200i,300,300i,400,400i,500,500i,600,600i,700,700i&amp;subset=latin-ext,thai,vietnamese" rel="stylesheet">
	<!-- //google fonts -->
	
</head>
<body>

<!-- header -->
<header class="bg-white py-1">
	<div class="container">
		<nav class="navbar navbar-expand-lg navbar-light">
			<h1>
				<a class="navbar-brand" href="home"><!--i class="fab fa-apple"></i--> Pesantren Indonesia</a>
			</h1>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-lg-4 mr-auto">
				  <li class="nav-item active">
					<a class="nav-link" href="pencarian">Cari Pesantren <span class="sr-only">(current)</span></a>
				  </li>
                    <li class="nav-item">
					<a class="nav-link" href="daftarkanpesantren">Daftarkan Pesantren</a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link" href="contact">Kontak</a>
				  </li>
				</ul>
				<div class="header-right">
					<a href="<?= base_url('auth'); ?>" class="signin mr-4"> Masuk <i class="fas fa-sign-in-alt"></i></a>
					<a href="<?= base_url('auth/registration'); ?>" class="contact">DAFTAR</a>
				</div>
			</div>
		</nav>
	</div>
</header>
<!-- //header -->

<!-- banner -->
<section class="banner">
	<div class="container">
		<div class="row banner-grids">
			<div class="col-lg-6 banner-info">
				<h2 class="">Informasi Pesantren di</h2>
				<h3 class="mb-3">Indonesia</h3>
				<p class="mb-4"> Temukan informasi mengenai pesantren di seluruh Indonesia dari sumber terpercaya. Anda juga bisa mendaftarkan atau menambahkan informasi mengenai pesantren dengan mudah agar menjadi kebermanfaatan bagi semuanya.</p>
				<a href="daftar">DAFTAR SEKARANG</a>
			</div>
			<div class="col-lg-6 col-md-9 banner-image">
				<img src="assets/images/lugu.JPG" alt="" class="img-fluid"/>
			</div>
		</div>
	</div>
</section>
<!-- //banner -->

<!-- about -->
<section class="about py-5">
	<div class="container">
		<div class="inner-sec-w3ls py-lg-5 py-3">
			<div class="heading">
				<h3 class="head text-center">Cari Pesantren </h3>
				<p class="my-3 head text-center"> Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Nulla mollis dapibus nunc, ut rhoncus
				turpis sodales quis. Integer sit amet mattis quam.</p>
			</div>
		          <form class="example" action="pencarian">
                    <input type="text" placeholder="Ketik nama pesantren disini..." name="search">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
		</div>
	</div>
</section>
<!-- //about -->

<!-- latest news -->
<section class="latest-news py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center">Pencarian Populer </h3>
			<p class="my-3 head text-center"> Berikut ini adalah pencarian populer pesantren yang ada di Indonesia. <br>
                Untuk melihat informasi pesantren lainnya, Anda dapat melihat laman Cari Pesantren.</p>
		</div>
		<div class="row news_grids mx-auto mt-5 pt-3">
			<div class="row col-lg-10 p-lg-auto p-0 mx-auto">
				<div class="col-md-6">
					<div class="blog-post mb-4">
						<div class="bg-light p-4">
							<h5 class="card-title">Management Values</h5>
							<h4 class="">The working process of our team work</h4>
						</div>
						<img src="assets/images/bp1.jpg" alt="" class="img-fluid"/>
					</div>
					<a href="#"> Selengkapnya </a>
				</div>
				<div class="col-md-6 mt-md-0 mt-5">
					<div class="blog-post mb-4">
						<div class="bg-light p-4">
							<h5 class="card-title">Management Values</h5>
							<h4 class="">The working process of our team work</h4>
						</div>
						<img src="assets/images/bp2.png" alt="" class="img-fluid"/>
					</div>
					<a href="#"> Selengkapnya </a>
				</div>
				<div class="col-12 text-center">
					<a href="pencarian" class="more_blog_link">Lihat Pesantren Lainnya</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //latest news -->

<!-- improvements -->
<section class="stats bg-light py-5">
	<div class="container py-md-5">
		<div class="heading">
			<h3 class="head text-center">Visi &amp; Misi</h3>
			<p class="my-3 head text-center"> Pesantren Indonesia merupakan website kumpulan informasi mengenai pesantren-pesantren di seluruh wilayah Indonesia dengan tujuan dapat menjalin silaturahmi antar pesantren dan juga pihak luar.</p>
		</div>
		<div class="row text-center mt-5"> 
			<div class="col-md-4">
				<div class="bg-white p-4">
					<!--h4>1</h4-->
					<p class="my-3"> Meningkatkan hubungan antar pesantren di seluruh wilayah Indonesia </p>
				</div>
			</div>
			<div class="col-md-4 mt-md-0 mt-3">
				<div class="bg-white p-4">
					<!--h4>2</h4-->
					<p class="my-3"> Mengetahui dan meningkatkan kerja, kinerja, SDA, dan SDM yang ada di pesantren </p>
				</div>
			</div>
			<div class="col-md-4 mt-md-0 mt-3">
				<div class="bg-white p-4">
					<!--h4>3</h4-->
					<p class="my-3"> Menjalin kerjasama yang saling menguntungkan antar pesantren dan pihak luar </p>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //improvements -->

<!-- copyright -->
<section class="copy-right bg-light py-4">
	<div class="container">
		<div class="row">
			<div class="col-lg-7 col-md-9">
				<p class="">© 2019 Pesantren Indonesia. All rights reserved
			</div>
			<div class="col-lg-5 col-md-3">
				<ul class="social-iconsv2 agileinfo d-flex">
					<li>
						<a href="#">
							<i class="fab fa-facebook-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-twitter-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-google-plus-square"></i>
						</a>
					</li>
					<li>
						<a href="#">
							<i class="fab fa-linkedin"></i>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
</section>
<!-- copyright -->

    <!-- js -->
    <script src="assets/js/jquery-2.2.3.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <!-- //js -->
	
	<!-- dropdown nav -->
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                    $(this).toggleClass('open');
                },
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                    $(this).toggleClass('open');
                }
            );
        });
    </script>
    <!-- //dropdown nav -->

	<script src="assets/js/smoothscroll.js"></script><!-- Smooth scrolling -->


</body>
</html>