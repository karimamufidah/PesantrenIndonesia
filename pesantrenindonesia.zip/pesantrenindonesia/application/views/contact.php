
<!-- Contact -->
<section class="contact py-5">
	<div class="container py-md-3">
		<div class="heading">
			<h3 class="head text-center"><?= $title; ?> </h3>
			<p class="my-3 head text-center"> Jika ada pertanyaan, kritik, dan saran, Anda dapat menghubungi kami <br>dengan cara mengisi data di bawah ini.</p>
		</div>
		<div class="contact-form mt-5">
			<div class="row">
				<div class="col-lg-7 col-md-10 mx-auto">
					<form name="contactform" id="contactform" method="post" action="#" onsubmit="return(validate());" novalidate="novalidate">
						<div class="form-group">
						  <label>Nama</label>
						  <input type="text" class="form-control" id="name" placeholder="Masukkan Nama" name="name">
						</div>
						<div class="form-group">
						  <label>Email</label>
						  <input type="email" class="form-control" id="email" placeholder="Masukkan Email" name="email">
						</div>
						
						<div class="form-group">
						  <label>No Telepon</label>
						  <input type="text" class="form-control" id="phone" placeholder="Masukkan No Telepon" name="phone">
						</div>
						<div class="form-group">
						  <label>Subject</label>
						  <input type="text" class="form-control" id="subject" placeholder="Subject" name="subject">
						</div>
						<div class="form-group">
						  <label>How can we help?</label>
						  <textarea name="issues" class="form-control" id="iq" placeholder="Masukkan Pesan Anda"></textarea>
						</div>				
						<button type="submit" class="btn btn-default">Kirim</button>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Contact -->

<!-- map -->
<section class="agileits-w3layouts-map">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d375.29505260451043!2d112.79714921506603!3d-7.314491158945294!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fa90258c467b%3A0xd7de065e8471cf10!2ssurabayandrfarm.blogspot.com!5e0!3m2!1sen!2sid!4v1556488424951!5m2!1sen!2sid" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</section>
<!-- //map -->


<!-- footer -->
<!--footer class="footer py-5">
	<div class="container py-sm-4">
		<div class="row">
			<div class="col-lg-4 mb-lg-0 mb-4 footer-top">
				<h2>
				<a class="navbar-brand" href="home"><i class="fab fa-python"></i> Work</a>
				</h2>
				<p class="my-3 head"> Vestibulum ante ipsum primis in faucib orci luctus et ultrices posuere cubilia Curae, Nul mollis dapibus nunc, ut rhoncus
				turpis sod quis. Integer sit amet mattis quam.</p>
			</div>
			<div class="col-lg-2 col-sm-3 col-6 footv3-left">
				<h4 class="mb-4 w3f_title text-uppercase">Company</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="about">
							About Us
						</a>
					</li>
					<li class="mb-2">
						<a href="features">
							Features
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Projects
						</a>
					</li>
					<li class="my-2">
						<a href="blogs">
							Blog Posts
						</a>
					</li>
					<li>
						<a href="contact">
							Get In Touch
						</a>
					</li>
				</ul>
			</div>
			<div class="col-lg-2 col-sm-3 col-6">
				<h4 class="mb-4 w3f_title text-uppercase">Product</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Why Us?
						</a>
					</li>
					<li class="mb-2">
						<a href="features">
							Features
						</a>
					</li>
					<li class="my-2">
						<a href="security">
							Security
						</a>
					</li>
					<li class="my-2">
						<a href="pricing">
							Pricing
						</a>
					</li>
					<li>
						<a href="#">
							Settings
						</a>
					</li>
				</ul>
			</div>

			<div class="col-lg-2 col-sm-3 col-6 mt-sm-0 mt-4">
				<h4 class="mb-4 w3f_title text-uppercase">Resources</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Help Line
						</a>
					</li>
					<li class="mb-2">
						<a href="#">
							Steps To Follow
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Guidance
						</a>
					</li>
					<li class="my-2">
						<a href="#">
							Download
						</a>
					</li>
					<li>
						<a href="#">
							Mobile App
						</a>
					</li>
				</ul>
			</div>
			
			<div class="col-lg-2 col-sm-3 col-6 mt-sm-0 mt-4">
				<h4 class="mb-4 w3f_title text-uppercase">Extras</h4>
				<ul class="list-agileits">
					<li class="my-2">
						<a href="#">
							Extra Links
						</a>
					</li>
					<li class="mb-2">
						<a href="signin">
							Login
						</a>
					</li>
					<li class="my-2">
						<a href="register">
							Register
						</a>
					</li>
				</ul>
			</div>
			
		</div>
	</div>
	<!-- //footer bottom -->
<!--/footer-->
<!-- //footer -->
