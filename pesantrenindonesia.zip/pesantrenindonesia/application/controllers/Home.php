<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['title'] = 'Pesantren Indonesia';
		
		$this->load->view('templates/home_header', $data);
		$this->load->view('home/index', $data);
		$this->load->view('templates/home_footer');
	}

	public function search()
	{
		$data['title'] = 'Pesantren Indonesia| Search';

		$this->load->model('Pesantren_model', 'pesantren');

		$data['pesantren'] = $this->pesantren->getPesantren();
		$data['pesantren'] = $this->db->get_where('daftar_pesantren', ['status' => 1])->result_array();
		
		$this->load->view('templates/home_header', $data);
		$this->load->view('home/search', $data);
		$this->load->view('templates/home_footer');
	}

	public function searchbutton()
	{
		$data['title'] = 'Pesantren Indonesia| Search';

		$this->load->model('Pesantren_model', 'pesantren');
		$data['pesantren'] = $this->pesantren->cariPesantren();
		$data['pesantren'] = $this->db->get_where('daftar_pesantren', ['status' => 1])->result_array();
		
		$this->load->view('templates/home_header', $data);
		$this->load->view('home/search', $data);
		$this->load->view('templates/home_footer');
	}

	public function register()
	{
		$this->form_validation->set_rules('namaPesantren', 'Nama Pesantren', 'required|trim');
		$this->form_validation->set_rules('namaPengurus', 'Nama Pengurus', 'required|trim');
		$this->form_validation->set_rules('jabatanPengurus', 'Jabatan Pengurus', 'required|trim');
		$this->form_validation->set_rules('emailPesantren', 'Email', 'required|trim');
		$this->form_validation->set_rules('websitePesantren', 'Website');
		$this->form_validation->set_rules('notelp', 'No Telepon', 'required|trim');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required|trim');
		$this->form_validation->set_rules('provinsi', 'Provinsi', 'required|trim');
		$this->form_validation->set_rules('kabkota', 'Kabupaten/Kota', 'required|trim');
		$this->form_validation->set_rules('kodepos', 'Kode pos', 'required|trim');
		$this->form_validation->set_rules('gambar', 'Gambar', 'required|trim');
		
		if($this->form_validation->run() == false) {
			$data['title'] = 'Pesantren Indonesia| Register';

			$this->load->view('templates/home_header', $data);
			$this->load->view('home/register', $data);
			$this->load->view('templates/home_footer');
		} else {
			$data = [
				'nama_pesantren' => htmlspecialchars($this->input->post('namaPesantren', true)),
				'nama_pengurus' => htmlspecialchars($this->input->post('namaPengurus', true)),
				'jabatan_pengurus' => htmlspecialchars($this->input->post('jabatanPengurus', true)),
				'email_pesantren' => htmlspecialchars($this->input->post('emailPesantren', true)),
				'website_pesantren' => htmlspecialchars($this->input->post('websitePesantren', true)),
				'notelp_pesantren' => htmlspecialchars($this->input->post('notelp', true)),
				'alamat_pesantren' => htmlspecialchars($this->input->post('alamat', true)),
				'provinsi_pesantren' => htmlspecialchars($this->input->post('provinsi', true)),
				'kab_kota_pesantren' => htmlspecialchars($this->input->post('kabkota', true)),
				'kodepos_pesantren' => htmlspecialchars($this->input->post('kodepos', true)),
				'foto_pesantren' => htmlspecialchars($this->input->post('gambar', true))
				
			];

			$this->db->insert('daftar_pesantren', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your input has been submited!</div>');
			redirect('home/register');
		}
	}

	public function contact()
	{

		$this->form_validation->set_rules('nama', 'Nama', 'required|trim');
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		$this->form_validation->set_rules('notelp', 'No Telepon', 'required|trim');
		$this->form_validation->set_rules('subject', 'Subject', 'required|trim');
		$this->form_validation->set_rules('message', 'Message', 'required|trim');

		if($this->form_validation->run() == false){
			$data['title'] = 'Pesantren Indonesia| Contact';
		
			$this->load->view('templates/home_header', $data);
			$this->load->view('home/contact', $data);
			$this->load->view('templates/home_footer');
		} else {
			$data = [
					'nama' => htmlspecialchars($this->input->post('nama', true)),
					'email' => htmlspecialchars($this->input->post('email', true)),
					'notelp' => htmlspecialchars($this->input->post('notelp', true)),
					'subject' => htmlspecialchars($this->input->post('subject', true)),
					'pesan' => htmlspecialchars($this->input->post('message', true)),
			];

			$this->db->insert('inbox', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your message has been sent!</div>');
			redirect('home/contact');
		}
		
	}

	public function detail($id_pesantren)
	{
		$data['title'] = 'Detail Pesantren';

		$this->load->model('Pesantren_model', 'pesantren');
		$data['pesantren'] = $this->pesantren->getPesantrenById($id_pesantren);
		// $this->db->bind('id_pesantren', $id_pesantren);
		
		$this->load->view('templates/home_header', $data);
		$this->load->view('home/detail', $data);
		$this->load->view('templates/home_footer');
	}


}
