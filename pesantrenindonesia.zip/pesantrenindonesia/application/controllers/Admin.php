<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller 
{	

	public function __construct()
	{
		parent::__construct();
		is_logged_in();
	}

	public function index()
	{
		$data['title'] = 'Dashboard';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/index', $data);
		$this->load->view('templates/footer');

	}

	public function role()
	{
		$data['title'] = 'Role';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$data['role'] = $this->db->get('user_role')->result_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/role', $data);
		$this->load->view('templates/footer');

	}

	public function roleAccess($role_id)
	{
		$data['title'] = 'Role Access';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();

		$this->db->where('id !=', 1);
		$data['menu'] = $this->db->get('user_menu')->result_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/role-access', $data);
		$this->load->view('templates/footer');

	}

	public function changeAccess()
	{
		$menu_id = $this->input->post('menuId');
		$role_id = $this->input->post('roleId');

		$data = [
			'role_id' => $role_id,
			'menu_id' => $menu_id
		];

		$result = $this->db->get_where('user_access_menu', $data);

		if($result->num_rows() < 1){
			$this->db->insert('user_access_menu', $data);
		} else {
			$this->db->delete('user_access_menu', $data);
		}

		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Access change!</div>');
	}

	public function approval()
	{
		$data['title'] = 'Approval';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Pesantren_model', 'pesantren');

		$data['pesantren'] = $this->pesantren->getPesantren();
		$data['pesantren'] = $this->db->get('daftar_pesantren')->result_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/approval', $data);
		$this->load->view('templates/footer');

	}

	public function inbox()
	{
		$data['title'] = 'Inbox';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Inbox_model', 'inbox');

		$data['inbox'] = $this->inbox->getInbox();
		$data['inbox'] = $this->db->get('inbox')->result_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/inbox', $data);
		$this->load->view('templates/footer');

	}

	public function userList()
	{
		$data['title'] = 'User List';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Userlist_model', 'user');

		$data['userlist'] = $this->user->getUser();
		$data['userlist'] = $this->db->get('user')->result_array();
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/userlist', $data);
		$this->load->view('templates/footer');

	}

	public function detailInbox($id)
	{
		$data['title'] = 'Detail';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Inbox_model', 'inbox');
		$data['inbox'] = $this->inbox->getInboxById($id);
		// $this->db->bind('id_pesantren', $id_pesantren);
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/detail', $data);
		$this->load->view('templates/footer');
	}

	public function deleteinbox($id)
	{
		$data['title'] = 'Delete';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Inbox_model', 'inbox');
		$id = $this->input->get('id');
		if($this->inbox->delete)
		$data['inbox'] = $this->inbox->deleteInboxById($id);
		// $this->db->bind('id_pesantren', $id_pesantren);
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/inbox', $data);
		$this->load->view('templates/footer');
	}

	public function detail($id_pesantren)
	{
		$data['title'] = 'Detail Pesantren';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Pesantren_model', 'pesantren');
		$data['pesantren'] = $this->pesantren->getPesantrenById($id_pesantren);
		// $this->db->bind('id_pesantren', $id_pesantren);
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/detail', $data);
		$this->load->view('templates/footer');
	}

	public function approve($id_pesantren)
	{
		$data['title'] = 'Approve Pesantren';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Pesantren_model', 'pesantren');
		$data['pesantren'] = $this->pesantren->approvePesantren(['status' => 1],'daftar_pesantren');
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/approval', $data);
		$this->load->view('templates/footer');
	}

	public function delete($id_pesantren)
	{
		$data['title'] = 'Detail Pesantren';
		$data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

		$this->load->model('Pesantren_model', 'pesantren');
		$where = array('id_pesantren' => $id_pesantren);
		$data['pesantren'] = $this->pesantren->deletePesantren($where,'daftar_pesantren');
		
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('admin/approval', $data);
		$this->load->view('templates/footer');
	}

}