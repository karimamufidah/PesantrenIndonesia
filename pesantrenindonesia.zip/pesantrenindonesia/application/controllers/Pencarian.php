<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pencarian extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        
        $this->load->model('ProvinsiModel');
        $this->load->model('KabkotaModel');
    }
    
    public function index() {
        $data['provinsi'] = $this->ProvinsiModel->view();
        
        $this->load->view('pencarian', $data);
    }
    
    public function listKabkota(){
        //Ambil data ID Provinsi yang dikirim via ajax post
        $id_provinsi = $this->input->post('id_provinsi');
        
        $kabkota = $this->KabkotaModel->viewByProvinsi($id_provinsi);
        
        //Buat variabel untuk menampung tag-tag option nya
        //Set defaultnya dengan tag option Pilih
        $lists = "<option value=''>Pilih</option>";
    
        foreach($kabkota as $data){
            $lists .= "<option value='".$data->id_kabkota."'>".$data->kabkota."</option>"; // Tambahkan tag option ke variabel $lists
        }
    
        $callback = array('list_kabkota'=>$lists); // Masukan variabel lists tadi ke dalam array $callback dengan index array : list_kabkota
    
        echo json_encode($callback); // konversi varibael $callback menjadi JSON
        
    }
}