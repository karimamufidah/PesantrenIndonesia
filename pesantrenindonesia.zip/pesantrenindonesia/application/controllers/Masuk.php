<?php

class Masuk extends CI_Controller {
    public function index() {
        $this->load->view('masuk');
    }
}