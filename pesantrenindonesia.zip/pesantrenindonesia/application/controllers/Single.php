<?php

class Single extends CI_Controller {
    public function index() {
        $this->load->view('single');
    }
}