<?php

class History extends CI_Controller {
    public function index() {
        $this->load->view('history');
    }
}