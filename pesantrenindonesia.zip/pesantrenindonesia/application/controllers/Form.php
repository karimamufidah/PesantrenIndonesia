<?php

class Form extends CI_Controller {
    public function index() {
        $this->load->view('form');
    }
}