<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesantren_model extends CI_Model
{

	public function getPesantren()
	{
		$query = "SELECT * 
				  FROM `daftar_pesantren`";

		return $this->db->query($query)->result_array();
	}

	public function getPesantrenById($id_pesantren)
	{
		$query = "SELECT * 
				  FROM `daftar_pesantren` 
				  WHERE `daftar_pesantren`.`id_pesantren` = $id_pesantren";

		return $this->db->query($query)->result_array();
	}

	public function approvePesantren($data,$table)
	{
		$this->db->update($table, $data);
	}

	public function deletePesantren($where,$table)
	{
		$this->db->where($where);
		$this->db->delete($table);
	}

	public function cariPesantren(){
		//$keywoard = $_POST['keywoard'];
		$query = "SELECT * FROM daftar_pesantren WHERE nama_pesantren LIKE %:keywoard%";
		$this->db->query($query);
		return $this->db->resultSet();
	}
}