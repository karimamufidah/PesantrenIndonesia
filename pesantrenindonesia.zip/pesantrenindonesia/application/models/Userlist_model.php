<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Userlist_model extends CI_Model
{

	public function getUser()
	{
		$query = "SELECT *
				  FROM `user`";
		return $this->db->query($query)->result_array();
	}
}