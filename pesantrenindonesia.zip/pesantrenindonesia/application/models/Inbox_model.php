<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inbox_model extends CI_Model
{

	public function getInbox()
	{
		$query = "SELECT *
				  FROM `inbox`";
		return $this->db->query($query)->result_array();
	}
	public function getInboxById($id)
	{
		$query = "SELECT * 
				  FROM `inbox` 
				  WHERE `inbox`.`id` = $id";

		return $this->db->query($query)->result_array();
	}
	public function deleteinbox($id)
	{
		$this->load->database();
		$this->db->where('id',$id);
		$this->db->delete();
		return true;
	}
}